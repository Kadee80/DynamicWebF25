This is a React Starter Project for use in Stephen Grider's courses on Udemy.
